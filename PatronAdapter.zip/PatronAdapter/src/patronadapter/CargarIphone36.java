/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patronadapter;


public class CargarIphone36 {//adaptee
    
    public void CargarIphone36(){
        System.out.println("Cargando iPhone 36 Plus+...");
    }
    
}
